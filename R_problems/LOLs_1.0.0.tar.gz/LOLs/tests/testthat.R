library(testthat)
library(LOLs)

test_check("LOLs")
