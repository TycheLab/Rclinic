test_that("Pennyworth basic test", {
  expect_is(object = secRet(), 
            class = c("gg", "ggplot"))
})
