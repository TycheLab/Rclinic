test_that("love basic test", {
  expect_is(object = eveRloving(), 
            class = c("gg", "ggplot"))
})
