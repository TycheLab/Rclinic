test_that("Neo basic test", {
  expect_is(object = matRix(), 
            class = c("gg", "ggplot"))
})
