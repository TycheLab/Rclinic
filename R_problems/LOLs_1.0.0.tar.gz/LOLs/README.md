# LOLs

<!-- badges: start -->
[![Travis build status](https://travis-ci.org/strnda/LOLs.svg?branch=master)](https://travis-ci.org/strnda/LOLs)
[![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/strnda/LOLs?branch=master&svg=true)](https://ci.appveyor.com/project/strnda/LOLs)
[![CRAN status](https://www.r-pkg.org/badges/version/LOLs)](https://CRAN.R-project.org/package=LOLs)
[![license](https://img.shields.io/badge/license-GPL3-lightgrey.svg)](https://choosealicense.com/)
<!-- badges: end -->

The goal of LOLs is to push the limits of creativity and imagination.

## Installation

You can install the released version of LOLs from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("LOLs")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(LOLs)
## basic example code
```

