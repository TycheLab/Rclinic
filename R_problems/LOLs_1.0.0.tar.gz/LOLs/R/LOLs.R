#' LOLs
#'
#' LOLs is a package that incorporates data manipulation including parametric equations into framework allowing user to push the limits of creativity and imagination.
#' 
#' @author \strong{Coded and maintained by:} Filip Strnad \email{strnadf@fzp.czu.cz}
#'
#' @docType package
#' @name LOLs-package
NULL
#> NULL
