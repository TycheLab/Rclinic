#' Helper function
#'
#' @param x character vector of packages
#'
#' @keywords internal
#' 
#' @import utils
#' @export
#'
#' @examples
#' 
#' req.aux('base')
req.aux <- function(x) {
  
  if(!suppressWarnings(
    suppressMessages(
      require(package = x, 
              character.only = TRUE)))) {
    
    install.packages(pkgs = x)
    
    require(package = x,
            character.only = TRUE)
  }
}

#' Install and Load Packages from Repositories
#' 
#' Download, install and load packages from CRAN-like repositories
#' 
#' @param ... character vector of packages
#'
#' @export
#'
#' @examples
#' 
#' library(LOLs)
#' 
#' load.packages(c('ggplot2', 'data.table'))
load.packages <- function(...){
  
  invisible(lapply(..., req.aux))
}

